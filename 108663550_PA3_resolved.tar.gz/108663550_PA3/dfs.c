/*
DFS : SERVER SIDE PROGRAM
Run as ./dfs /DFS1 <portnumber>
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <time.h>
#include <dirent.h>
#include <signal.h>
#include <unistd.h>

#define BUFSIZE 10240

#define GET_FILE 1
#define PUT_FILE  2
#define LIST_FILES 3
#define CLOSE_SOC 4

char File_List[10];
int file_counter=0;

typedef struct user_credential{
  char USERNAME[100];
  char PASSWORD[100];
}ucreds;
char dfsconfig[100];
ucreds CurrentUser;

int strToInt(char *str)
{
int num = 0;
int i=0;

  for (i = 0; str[i] != '\0'; i++)
  {
      num = num * 10 + str[i] - '0';  // Converts String to integer
  }
  return num;
}



int send_func(int sockfd, char *filename, struct sockaddr_in clientAddr, int PortIndex, int fileNumber){
  printf("\n\nSSSSSSSSSSSSSSSSSSSSSSSSSSSSS\nEntering the send function\n\n");
   FILE *f1;                   // Reads the file
   char subfolder[100];

   size_t  read_size, stat;
   int packet_index, size;
   struct timeval timeout = {2,0}; // determines the timeout
   char send_buffer[1024], read_buffer[256];
   char systemListCmd[200];
   bzero(systemListCmd, sizeof(systemListCmd));
   packet_index = 1;

  fd_set fds;
  int buffer_fd, buffer_out, flags;
  socklen_t servlen = sizeof(clientAddr);  // new

  char dfsFolder[100];
  bzero(dfsFolder, sizeof(dfsFolder));

  // variables for opeing a directory
  DIR           *d;
  struct dirent *dir;
  int count = 0;
  int index = 0;
  char name[256][256];

  // receive the subfolder name
  stat = recv(sockfd, subfolder, 100, 0);  // reading the filename
  if (stat < 0)
    perror("Error receiving subfolder");

  printf("\n\nsubfolder to get from: %s\n", subfolder);


  // USED for list
  if (fileNumber == -1)
  {
    if (strcmp(subfolder,"/") == 0)
    {
      sprintf(systemListCmd, "ls DFS%d/%s > DFS%d/%s/.%s", PortIndex, CurrentUser.USERNAME, PortIndex, CurrentUser.USERNAME, filename);
      printf("systemListCmd %s\n", systemListCmd);
      system(systemListCmd);
      printf("\n\nEmpty subfolder received\n\n");
      // have to send an acknowledgement if subfolder is present or not
    }
    else
    {
      sprintf(systemListCmd, "ls DFS%d/%s/%s > DFS%d/%s/%s/.%s", PortIndex, CurrentUser.USERNAME, subfolder,PortIndex, CurrentUser.USERNAME, subfolder,filename);
      printf("systemListCmd %s\n", systemListCmd);
      system(systemListCmd);
    }

  }
  char dirToOpenWithUser[100];
  switch(PortIndex)
  {
    case 1:
      strncpy(dfsFolder, "DFS1", sizeof("DFS1"));
      strncpy(dirToOpenWithUser, "./DFS1/", sizeof("./DFS1/"));
      strncat(dirToOpenWithUser, CurrentUser.USERNAME, strlen(CurrentUser.USERNAME));

    break;
    case 2:
      strncpy(dfsFolder, "DFS2", sizeof("DFS2"));
      strncpy(dirToOpenWithUser, "./DFS2/", sizeof("./DFS2/"));
      strncat(dirToOpenWithUser, CurrentUser.USERNAME, strlen(CurrentUser.USERNAME));

    break;
    case 3:
      strncpy(dfsFolder, "DFS3", sizeof("DFS3"));
      strncpy(dirToOpenWithUser, "./DFS3/", sizeof("./DFS3/"));
      strncat(dirToOpenWithUser, CurrentUser.USERNAME, strlen(CurrentUser.USERNAME));
    break;
    case 4:
      strncpy(dfsFolder, "DFS4", sizeof("DFS4"));
      strncpy(dirToOpenWithUser, "./DFS4/", sizeof("./DFS4/"));
      strncat(dirToOpenWithUser, CurrentUser.USERNAME, strlen(CurrentUser.USERNAME));
    break;
  }
  if (strcmp(subfolder,"/") == 0)
    printf("\n\nEmpty subfolder received\n\n");
  else
    sprintf(dirToOpenWithUser, "%s/%s", dirToOpenWithUser, subfolder);

  printf("Directory to be opened: %s\n", dirToOpenWithUser);


  char filename_dummy[100];
  bzero(filename_dummy, sizeof(filename_dummy));

  sprintf(filename_dummy,"%s",filename);


  // copies the current list of files in to the array name[count]

  int filestatus = -5;
  if (fileNumber != -1)
  {
    d = opendir(dirToOpenWithUser);
    if (d)
    {
      printf("\nOpening directory\n");
      while ((dir = readdir(d)) != NULL)
      {
        printf("%s\n%s\n",dir, dir->d_name);
        if (strncmp(dir->d_name, filename_dummy, strlen(filename)) == 0)
        {
          if ((dir->d_name[strlen(filename) + 2]>=0) &&  (dir->d_name[strlen(filename) + 2]<=3))
          {
            strcpy(name[count],dir->d_name);
            printf("name[count]: %s\n", name[count]);
            count++;
          }
        }

      }

      closedir(d);
    }
    else
      printf("FILE NOT FOUND\n");

    if (count == 0)
    filestatus = 0;
  }


  strncat(dfsFolder,"/",sizeof("/"));
  strncat(dfsFolder,CurrentUser.USERNAME,sizeof(CurrentUser.USERNAME));
  strncat(dfsFolder,"/",sizeof("/"));
  strncat(dirToOpenWithUser,"/",sizeof("/"));
  printf("\ndfsFolder :%s\n", dfsFolder);
  char filenameWithDot[100];
  bzero(filenameWithDot,sizeof(filenameWithDot));
  printf("%s\n",name[fileNumber]);
  if (fileNumber != -1)
    strcat(filenameWithDot, name[fileNumber]);
  else
  {
    sprintf(filenameWithDot, ".%s", filename);
    if (strcmp(subfolder,"/") != 0)
      sprintf(dfsFolder,"%s%s/",dfsFolder, subfolder);
  }
  printf("filename :%s\n", filename);
  printf("filenameWithDot: %s\n", filenameWithDot);
  // sending the filename from server to client
  send(sockfd, filenameWithDot, sizeof(filenameWithDot), 0);
  strncat(dirToOpenWithUser,filenameWithDot, sizeof(filenameWithDot));
  printf("dfs folder latest after concatenation:%s\n", dirToOpenWithUser);

  char checkFileExists[200];
   bzero(checkFileExists, sizeof(checkFileExists));
   printf("fileNumber %d\n", fileNumber);

   if (filestatus == 0)
   {
    printf("FILE UNAVAILABLE\n");
   }
   else if (fileNumber>=-1)
   {
      if (strcmp(subfolder,"/") == 0)
      {
        sprintf(checkFileExists,"DFS%d/%s/%s",PortIndex,CurrentUser.USERNAME,filenameWithDot);
      }
      else
      {
       sprintf(checkFileExists,"DFS%d/%s/%s/%s",PortIndex,CurrentUser.USERNAME,subfolder,filenameWithDot);
      }
      if (access (checkFileExists, F_OK) != -1)
       {
        printf("File exists\n");
          filestatus = 1;
           send(sockfd, (void *)&filestatus, sizeof(int), 0);
          if (stat < 0)
         {
          perror("Error sending size");
          exit(1);
         }

       }
       else
       {
        filestatus = 0;
        printf("File does not exist\n");
           send(sockfd, (void *)&filestatus, sizeof(int), 0);
          if (stat < 0)
         {
          perror("Error sending size");
          exit(1);
         }

       }

   }
   else
   {
    filestatus = -1;
               send(sockfd, (void *)&filestatus, sizeof(int), 0);
          if (stat < 0)
         {
          perror("Error sending size");
          exit(1);
         }

   }

   if (filestatus == 1 || filestatus == -1)
   {
      if (!(f1 = fopen(dirToOpenWithUser, "r")))
      {
        perror("fopen");
      }
      bzero(dfsFolder, sizeof(dfsFolder));
            bzero(dirToOpenWithUser, sizeof(dirToOpenWithUser));
       printf("Finding the size of the file using fseek\n");

       fseek(f1, 0, SEEK_END);
       size = ftell(f1);
       fseek(f1, 0, SEEK_SET);
       printf("Total file size is: %d\n",size);


       printf("Sending file Size from Server to Client\n");
       send(sockfd, (void *)&size, sizeof(int), 0);
        if (stat < 0)
       {
        perror("Error sending size");
        exit(1);
       }


      char sendBuf_withpcktSize[BUFSIZE];

       while(!feof(f1)) {
          read_size = fread(send_buffer, 1, sizeof(send_buffer)-1, f1);


          do{

                stat = send(sockfd, send_buffer, read_size, 0);

          }while (stat < 0);

          printf(" \n");
          printf(" \n");


          //Zero out our send buffer
          bzero(send_buffer, sizeof(send_buffer));

         }
   }
}


int receive_func(int sockfd, struct sockaddr_in clientAddr, socklen_t clientlen, int PortIndex)
{

  int buffersize = 0, recv_size = 0, read_size, write_size,stat;
  int size = 0;
  char *buf;
  buf = malloc(300241);
  FILE *f2;
  char filename[100];
  char subfolder[100];
  printf("\n****************************\nEntering the receive_func function\n");

  read_size = 0;
  size = 1;
  // continue till the size of the file completes
  stat = 0;
  stat = recv(sockfd, &size, sizeof(int), 0);  // reading size of the file
  if (stat < 0)
  {
    perror("Error receiving Size");
  }
  printf("size of the file is %d\n", size);

  stat = recv(sockfd, filename, 100, 0);  // reading the filename
  if (stat < 0)
  {
    perror("Error receiving filename");
  }

  stat = recv(sockfd, subfolder, 100, 0);  // reading the filename
  if (stat < 0)
  {
    perror("Error receiving subfolder");
  }


  char filename_received[100];
  bzero(filename_received,sizeof(filename_received));
  strncat(filename_received, filename, 100);

  printf("Filename without received%s\n", filename);
  strncat(filename_received, "_received",100);
  printf("Filename received is %s\n", filename_received);

  char dfsFolder[100];
  bzero(dfsFolder, sizeof(dfsFolder));
  char FolderWithUsername[20];
  char FolderWithUsernameSubfolder[200];

  switch(PortIndex)
  {
    case 1:
      strncpy(dfsFolder, "./DFS1", sizeof("./DFS1"));
      system("mkdir -p DFS1");
      strncpy(FolderWithUsername, "mkdir -p DFS1/", strlen("mkdir -p DFS1/"));
    break;
    case 2:
      strncpy(dfsFolder, "./DFS2", sizeof("./DFS2"));
      system("mkdir -p DFS2");
      strncpy(FolderWithUsername, "mkdir -p DFS2/", strlen("mkdir -p DFS2/"));
    break;
    case 3:
      strncpy(dfsFolder, "./DFS3", sizeof("./DFS3"));
      system("mkdir -p DFS3");
      strncpy(FolderWithUsername, "mkdir -p DFS3/", strlen("mkdir -p DFS3/"));
    break;
    case 4:
      strncpy(dfsFolder, "./DFS4", sizeof("./DFS4"));
      system("mkdir -p DFS4");
      strncpy(FolderWithUsername, "mkdir -p DFS4/", strlen("mkdir -p DFS4/"));
    break;
  }
  printf("%d\n", strlen(FolderWithUsername));
FolderWithUsername[strlen(FolderWithUsername)]='\0';
printf("%s\n",CurrentUser.USERNAME);
printf("%s\n",FolderWithUsername);
  // creates DFS[]/Username
  strncat(FolderWithUsername, CurrentUser.USERNAME, strlen("Alice"));
  printf("\n\nFolder with the Username:%s\n\n", FolderWithUsername);

  system(FolderWithUsername);

  // creates DFS[]/Username/subfolder
  printf("subfolder %s\n", subfolder);
  if (strcmp(subfolder, "/") == 0)
  {
    printf("\n\nEmpty subfolder\n\n");
  }
  else
  {
    sprintf(FolderWithUsernameSubfolder,"mkdir -p %s/%s",FolderWithUsername, subfolder);
    system(FolderWithUsernameSubfolder);
  }

  strncat(dfsFolder,"/",sizeof("/")); //dfs folder with slash command DFS[]/
  strncat(dfsFolder,CurrentUser.USERNAME, strlen(CurrentUser.USERNAME)); //dfs folder with slash command DFS[]/USERNAME

  char filenameWithDot[100];
  bzero(filenameWithDot,sizeof(filenameWithDot));


  if (strcmp(subfolder, "/") == 0)
  {
    printf("\n\nNo subfolder\n\n");
  //  strcpy(subfolder,NULL);
  }
  else
  {
    sprintf(dfsFolder,"%s/%s",dfsFolder,subfolder);
  }

  strncat(dfsFolder,"/",sizeof("/")); //dfs folder with slash command DFS[]/USERNAME/
  //strncat(dfsFolder,filenameWithDot, sizeof(filenameWithDot));
  printf("Current Folder: %s\n", dfsFolder);
  strncpy(filenameWithDot,dfsFolder,strlen(dfsFolder));
  strcat(filenameWithDot, filename);

char current_directory[50];

printf("[debug]%s\n",filenameWithDot );
  // opening file in write mode
  f2 = fopen(filenameWithDot, "w");
  printf("%d\n",f2 );
  // file open error
  if( f2 == NULL) {
    printf("Error has occurred. The file could not be opened/ created\n");
    return -1;
  }

  // receiving the file from client
  while(recv_size < size)
  {

    read_size = recv(sockfd, buf, 300241, 0);
    printf("readsize is %d \n", read_size);
   fputs(buf, f2);

    recv_size += read_size;
    printf("Total received File size: %i\n",recv_size);
    printf(" \n");
    printf(" \n");

  }

  fclose(f2);
  bzero(FolderWithUsername, sizeof(FolderWithUsername));
  return 1;

}

static unsigned int get_file_size (FILE * fileDescriptor)
{
    unsigned int size;

    fseek(fileDescriptor, 0L, SEEK_END);
    size = ftell(fileDescriptor);
    fseek(fileDescriptor, 0L, SEEK_SET);

    return size;
}


int ValidUser(char *USERNAME1, char *PASSWORD1)
{
    printf("\n********************\nIn the valid user function\n");
    FILE *fp;
    char buf[200];
    char *val1;

    int i = 0;
    fp=fopen(dfsconfig,"r");
    if (fp == NULL)
    {

        perror(dfsconfig);
        exit(1);
    }

    else
    {

        unsigned int wsConfigFileSize = get_file_size (fp);

        //printf("dfs.conf size n = %d, filename = dfs.conf \n", wsConfigFileSize);
        printf("\nChecking for User validity\n");
        while(fgets(buf,wsConfigFileSize,fp)!=NULL) {
              val1=strtok(buf," \t\n");
              if ((strncmp(val1, USERNAME1, strlen(USERNAME1)) == 0)  &&  (strlen(val1)==strlen(USERNAME1)) )
              {

                val1 = strtok(NULL, " \t\n");
                if ((strncmp(val1, PASSWORD1, strlen(PASSWORD1)) == 0) &&  (strlen(val1)==strlen(PASSWORD1)))
                {
                  return 1; // valid
                }
              }

        }

        fclose(fp);
    }

    return 0; // invalid
}

int sendAckforUserdetails(int newsockfd)
{

  int n, ack_putfile;
  n = recv(newsockfd, CurrentUser.USERNAME, 100, 0);    // Reading the option from user side
  if (n < 0)
  {
    perror("option receiving failed");
    exit(1);
  }

  n = recv(newsockfd, CurrentUser.PASSWORD, 100, 0);    // Reading the option from user side
  if (n < 0)
  {
    perror("option receiving failed");
    exit(1);
  }

  ack_putfile = ValidUser(CurrentUser.USERNAME, CurrentUser.PASSWORD);


  n = send(newsockfd, &ack_putfile, sizeof(int), 0);  // reading size of the file
  if (n < 0)
  {
    perror("Error receiving ack for username and password");
  }
  return ack_putfile;
}

int main(int argc, char **argv)
{

  signal(SIGPIPE, SIG_IGN);
  int sockfd, newsockfd, portno;
  socklen_t clientlen;
  char buffer[256];
  struct sockaddr_in servAddr, clientAddr;
  int listDummy;
  int n;
  char fileNameList[10];
  if (argc < 3) {
     fprintf(stderr,"ERROR, no port provided or config file missing\n");
     exit(1);
  }
  sprintf(dfsconfig,"%s","dfs.conf");
  FILE *fp;
  fp=fopen(dfsconfig,"r");
    if (fp == NULL)
    {

        perror(dfsconfig);
        exit(1);
    }
  fclose(fp);
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0)
    error("ERROR opening socket");
  bzero((char *) &servAddr, sizeof(servAddr));
  portno = atoi(argv[2]);
  servAddr.sin_family = AF_INET;
  servAddr.sin_addr.s_addr = INADDR_ANY;
  servAddr.sin_port = htons(portno);
  if (bind(sockfd, (struct sockaddr *) &servAddr,
          sizeof(servAddr)) < 0)
          error("ERROR on binding");
  listen(sockfd,5);
  clientlen = sizeof(clientAddr);
  newsockfd = accept(sockfd,
             (struct sockaddr *) &clientAddr,
             &clientlen);
  if (newsockfd < 0)
      error("ERROR on accept");


  int option;
  char putFileName[50];
  char getFileName[50];
  int stat;
  int n1;
  FILE *checkFile;
  int ack_putfile;
  int PortIndex = portno%5;
  int iCanStart;
  int dummy;
	for (;;) {

      n = recv(newsockfd, (void *)&option, sizeof(int), 0);    // Reading the option from user side
      if (n < 0)
      {
        perror("option receiving failed");
      }
     // else
       // printf("\nOption received; Connection has been established");

    switch(option)
    {
      // This command sends the file to Client
      case GET_FILE:
      printf("\nGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG\n Entering the Get block\n");
              n = recv(newsockfd, (void *)&dummy, sizeof(int), 0);    // Reading the option from user side
              if (n < 0)
              {
                perror("option receiving failed");
              }

              n = recv(newsockfd, (void *)&iCanStart, sizeof(int), 0);    // Reading the option from user side
              printf("\n\nReceieved signal to send from the user\n");
              if (n < 0)
              {
                perror("option receiving failed");
              }
              if (iCanStart)
              {
                printf("\n\nReceiving the file name\n");
                  if (sendAckforUserdetails(newsockfd))
                  {
                    printf("\n\nUser authentication successful\n\n");
                    stat = recv(newsockfd, getFileName, 50,0);
                     if (stat < 0)
                     {
                      perror("Error sending filename");
                      exit(1);
                     }
                    printf("\n[check1]Requested file name: %s\n", getFileName);
                    // sending the file

                    send_func(newsockfd, getFileName, clientAddr, PortIndex, 0);
                    printf("Exiting the GET_FILE\n");
                    sleep(1);
                    stat = recv(newsockfd, getFileName, 50,0);
                     if (stat < 0)
                     {
                      perror("Error sending filename");
                      exit(1);
                     }
                    printf("The second file is: %s\n", getFileName);
                    // sending the file

                    send_func(newsockfd, getFileName, clientAddr, PortIndex, 1);
                    printf("Exiting the GET_FILE\n");
                }
              }

          option = 10;
      break;

      case PUT_FILE:
            // PortIndex tells which folder to store in
            if (sendAckforUserdetails(newsockfd))
            {
              // receiving fst file
              receive_func( newsockfd, clientAddr, clientlen,PortIndex);

              // receiving second file
              receive_func( newsockfd, clientAddr, clientlen,PortIndex);

            }
            option = 10;
            break;

      // This command send list of files in the current directory to client
      case LIST_FILES:
      printf("\n\nLSLSLSLSLSLSLSLSLSLSLS\nListing Block\n");
        if (sendAckforUserdetails(newsockfd))
        {
          stat = recv(newsockfd, fileNameList, 50,0);
          if (stat < 0)
          {
            perror("Error sending filename");
            exit(1);
          }
          printf("The file name asked for first time is %s\n", fileNameList);
          send_func(newsockfd, fileNameList, clientAddr, PortIndex, -1);
          sleep(1);
        }

           option = 10;
      break;

      // This command closes the server socket and exits the program
      case CLOSE_SOC:
        printf("Shutting Down...\n");
        close(sockfd);   // closing the socket and exiting
        exit(1);
        option = 10;
      break;

      default:
      break;

    }

	}

}
