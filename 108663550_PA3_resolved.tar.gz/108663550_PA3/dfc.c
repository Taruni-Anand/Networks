/*
DFC : CLIENT SIDE PROGRAM:
Run as: ./dfc dfc.conf

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#define BUFLEN 10248   // Choosing the packet size to 10248

#define GET_FILE 1
#define PUT_FILE 2
#define LIST_FILES 3
#define CLOSE_SOC 4

#define DFS_SERVER1  0
#define DFS_SERVER2  1
#define DFS_SERVER3  2
#define DFS_SERVER4  3
#define TRUE 1
#define FALSE 0

#define SUCCESS 1
#define FAIL 0
#define TIMEOUT 1
char configFile[100];

int strToInt(char *str)
{
int num = 0;
int i=0;

  for (i = 0; str[i] != '\0'; i++)
  {
      num = num * 10 + str[i] - '0';  // Converts String to integer
  }
  return num;
}

void menu()
{
	printf("\n\n");
	printf("1. GET\n");
	printf("2. PUT\n");
	printf("3. LIST\n");
	printf("4. EXIT\n");
	printf("\n\n");

}


char user_commands()
{
	char option[6];
	char index;
	menu();

	while(1)
	{
		scanf("%s", option);           // scans the input string from the user

		if (strcmp(option, "GET") == 0)
		{
			index = GET_FILE;
			break;
		}
		else if (strcmp(option, "PUT") == 0)
		{
			index = PUT_FILE;
			break;
		}
		else if (strcmp(option, "LIST") == 0)
		{
			index = LIST_FILES;
			break;
		}

		else if(strcmp(option, "EXIT") == 0)
		{
			index = CLOSE_SOC;
			printf("The servers are shutting down.");
			break;
		}

		else
		{
			printf("Invalid option:%s\n", option);
			menu();
		}


	}

	return index;
}

static unsigned int get_file_size (FILE * fileDescriptor)
{
    unsigned int size;

    fseek(fileDescriptor, 0L, SEEK_END);
    size = ftell(fileDescriptor);
    fseek(fileDescriptor, 0L, SEEK_SET);

    return size;
}


char Server_list[4][100], USERNAME[100], PASSWORD[100];
void readDfcconfig(int check)
{
    FILE *fp;
    char Buf[200];
    char *val1;

    int i = 0;
    fp=fopen(configFile,"r");
    if (fp == NULL)
    {

        perror("configFile");
        exit(1);
    }

    else
    {

        unsigned int wsConfigFileSize = get_file_size (fp);

        //printf("dfc.conf size n = %d, filename = dfc.conf \n", wsConfigFileSize);
        printf("\n\nReading the dfc.conf file\n");
        while(fgets(Buf,wsConfigFileSize,fp)!=NULL) {
            if (check){
	            if((strncmp(Buf,"Server",6)==0)  || (strncmp(Buf,"SERVER",6)==0) ) {
	                printf("Server Configuration: %s",Buf);
	                val1=strtok(Buf," \t\n");
	                val1 = strtok(NULL, " \t\n");

	                // validating the DFS_ string to find the information on server number
	                // and storing it accordingly into the array for easier use
	                if (val1[3] == '1'){
	                	val1 = strtok(NULL, " \t\n");
	                	strcpy(Server_list[DFS_SERVER1],val1);
	                	i = 0;
	                }
	                if (val1[3] == '2'){
	                	val1 = strtok(NULL, " \t\n");
	                	strcpy(Server_list[DFS_SERVER2],val1);
	                	i = 1;
	                }

	                if (val1[3] == '3'){
	                	val1 = strtok(NULL, " \t\n");
	                	strcpy(Server_list[DFS_SERVER3],val1);
	                	i =2;
	                }
	                if (val1[3] == '4'){
	                	val1 = strtok(NULL, " \t\n");
	                	strcpy(Server_list[DFS_SERVER4],val1);
	                	i =3;
	                }
	                printf("List of servers connecting:\n");
	                printf("%s\n",Server_list[i]);
	                bzero(Buf, sizeof(Buf));
	                i = i%4;
	            }
        	}else{
	            if(strncmp(Buf,"Username",8)==0) {
	                //printf("Buf: %s",Buf);
	                val1=strtok(Buf," \t\n");
	                val1 = strtok(NULL, " \t\n");
	                strcpy(USERNAME, val1);
	                //printf("%s \n", USERNAME);
	            	bzero(Buf, sizeof(Buf));
	            }

	            if(strncmp(Buf,"Password",8)==0) {
	                //printf("Buf: %s",Buf);
	                val1=strtok(Buf," \t\n");
	                val1 = strtok(NULL, " \t\n");
	                strcpy(PASSWORD, val1);
	                //printf("%s\n", PASSWORD);
	            	bzero(Buf, sizeof(Buf));
            	}

            }
        }

        fclose(fp);
    }

}


int send_func(int sockfd, char *filename, struct sockaddr_in servAddr, char *subfolder){
printf("\n***************************\nEntering the send function\n\n");
   FILE *f1;                 // Reads the file
   size_t read_size, stat;  // size: stores the total size of the file, read_size: stores the return value of func recvfrm()
   int size;
   size_t packet_index;           // Sequence number of the packer being sent
   char send_buffer[1024], read_buffer[256];  // send_buffer: buffer to send the packet read_buffer: reads the message server
   struct timeval timeout = {2,0}; // determines the timeout


	fd_set fds;
	int buffer_fd, buffer_out, flags;
    packet_index = 1;

   socklen_t servlen = sizeof(servAddr);	// determines the size of server address

	while(1)
	{
		if (!(f1 = fopen(filename, "r")))
		{
				perror("fopen");
				printf("List of available files:\n");
				system("ls");
				printf("Choose an existing file\n");
				scanf("%s", filename);
		}

		else{
			break;
		}
	}

   fseek(f1, 0, SEEK_END);
   size = ftell(f1);
   fseek(f1, 0, SEEK_SET);
   printf("Total file size is: %d\n",size);

   char filesize_filename[100];
   stat = send(sockfd, &size, sizeof(int), 0);// sending size of the file
   if (stat < 0)
   {
	perror("Error sending size");
   	exit(1);
   }
   // send file name
   stat = send(sockfd, filename, 100,0);
   if (stat < 0)
   {
	perror("Error sending filename");
   	exit(1);
   }
   //send subfolder
   stat = send(sockfd, subfolder, 100,0);
   if (stat < 0)
   {
	perror("Error sending subfolder");
   	exit(1);
   }


   printf("Transmitting...\n");

   while(!feof(f1)) {

      read_size = fread(send_buffer, 1, sizeof(send_buffer)-1, f1);  // reading a buffer of size 1024
      do{

	    stat = send(sockfd, send_buffer, read_size, 0);

	    if (stat < 0)
	    {
	    	perror("Error in sending file");
	    }

      }while (stat < 0);
      printf(" \n");
      printf(" \n");

      // zeroing out the send_buffer
      bzero(send_buffer, sizeof(send_buffer));
     }
}


int receive_func(int sockfd, char *filename, struct sockaddr_in servAddr, socklen_t clientlen, char *subfolder)
{

  int buffersize = 0, recv_size = 0, read_size, write_size,stat;
  int size = 0;
  char *buf;
  buf = malloc(300241);
  FILE *f2;

  printf("\nRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR\nEntering the receive function\n");

  read_size = 0;
  size = 1;
  // continue till the size of the file completes
  stat = 0;
  char filename_received[100];
  bzero(filename_received,sizeof(filename_received));

	// sending the subfolder to receive from
  printf("subfolder: %s\n", subfolder);
	stat = send(sockfd, subfolder, 100, 0);
	if (stat < 0)
	{
		perror("subfolder sending failed");
	}
  stat = recv(sockfd, filename_received, sizeof(filename_received), 0);  // reading size of the file
  if (stat < 0)
  {
    perror("Error receiving filename");
  }
  //receiving status of file
  int filestatus;
  stat = recv(sockfd, &filestatus, sizeof(int), 0);  // reading size of the file
  if (stat < 0)
  {
    perror("Error receiving filestatus");
  }
  if (filestatus == 0)
  {
  	printf("This File Does not exist.\n");
  }
  if (filestatus == 1 || filestatus == -1)
  {
	  stat = recv(sockfd, &size, sizeof(int), 0);  // reading size of the file
	  if (stat < 0)
	  {
	    perror("Error receiving Size");
	  }
	  printf("size of the file is %d\n", size);

	  strncat(filename_received, "_received",100);
	  printf("Received file: %s\n", filename_received);

	  f2 = fopen(filename_received, "w");
	  // file open error
	  if( f2 == NULL) {
	    printf("Error has occurred. The file could not be opened/ created\n");
	    return -1;
	  }
	  while(recv_size < size)
	  {

	    read_size = recv(sockfd, buf, 300241, 0);
	    if (read_size == 0)
	    {
	    	perror("Server Error: ");
	    	break;
	    }

	    write_size = fwrite(buf,1,read_size, f2);
	    printf("Written File size: %d\n",write_size);
	    recv_size += read_size;
	    printf("Total received File size: %i\n",recv_size);
	    printf(" \n");
	    printf(" \n");

	  }

	  fclose(f2);
	  return 1;
	}
	else
	{
		return 0;
	}


}

#define MAX_CONNECTIONS 4
struct sockaddr_in  servAddr[MAX_CONNECTIONS];
socklen_t servlen[MAX_CONNECTIONS];
int sockfd[MAX_CONNECTIONS], slen=sizeof(servAddr);
struct hostent *server;

void createMultipleSockets()
{

    int i = 0;
    int portNum;
    char *serverName;
    char *portStr;


    for (i=0;i<MAX_CONNECTIONS;i++)
    {
    	servlen[i] = sizeof(servAddr[i]);
    	serverName = strtok(Server_list[i], ":");
		portStr = strtok(NULL,"");;
		portNum = atoi(portStr);

			// Creation of a socket
		if ((sockfd[i]=socket(AF_INET, SOCK_STREAM, 0))==-1)
		{
			perror("Error opening socket");
		}

		server = gethostbyname(serverName);   // getting the address of the server

			// Creating a socket with port num and host address from the config file
		memset((char *)&servAddr[i], 0, sizeof(servAddr[i]));
		servAddr[i].sin_family = AF_INET;
		servAddr[i].sin_port = htons(portNum);
		bcopy((char *)server->h_addr,
	             (char *)&servAddr[i].sin_addr.s_addr,
	             server->h_length);

		// Connecting to the server socket

	    if (connect(sockfd[i],(struct sockaddr *) &servAddr[i],sizeof(servAddr[i])) < 0)
	    {
	    	perror("ERROR connecting socket");
	    }

	    struct timeval timeout;
	    timeout.tv_sec = TIMEOUT;
	    timeout.tv_usec = 0;

	    if (setsockopt (sockfd[i], SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout,
	                sizeof(timeout)) < 0)
	        error("setsockopt failed\n");
	    }
}


int sendUserDetails(int sockfd1)
{

	int n, ack_putfile;
    readDfcconfig(0);  // only reads username and password
	//printf("USERNAME %s\n", USERNAME);
	//printf("PASSWORD %s\n", PASSWORD);

	n = send(sockfd1, USERNAME, 100, 0);
	if (n < 0)
	{
		perror("option sending failed");
	}

	n = send(sockfd1, PASSWORD, 100, 0);
	if (n < 0)
	{
		perror("option sending failed");
	}

	//receiving the status for username and passwords sent

	n = recv(sockfd1, &ack_putfile, sizeof(int), 0);    // Reading the option from user side
    if (n < 0)
    {
      perror("Did not receive ACK");

    }

    if (!ack_putfile)
    {
    	printf("INAVLID USERNAME/PASSWORD");

    	return 0;
    }
    return 1;
}

//MD5 COMPUTATION

void computeMd5sum(char *filename, char md5sum[100])  {
    char systemmd5Cmd[100];
    strncpy(systemmd5Cmd, "md5sum ", sizeof("md5sum "));
    strncat(systemmd5Cmd, filename, strlen(filename));
    FILE *f = popen(systemmd5Cmd, "r");
    while (fgets(md5sum, 100, f) != NULL) {
	strtok(md5sum,"  \t\n");
    }
    pclose(f);
}


int main(int argc, char **argv)
{

	if (argc < 2) {
     	fprintf(stderr,"Run with conf file as arguement\n");
     	exit(1);
  	}
  	sprintf(configFile,"%s",argv[1]);
  	FILE *fp;
  	fp=fopen(configFile,"r");
    if (fp == NULL)
    {

        perror(configFile);
        exit(1);
    }
  	fclose(fp);
  	printf("%s\n", configFile);

	signal(SIGPIPE, SIG_IGN);//SIG_IGN ignores the failed signal
	char md5sum[100];
	int md5sumInt;
	int sendFailedArray[MAX_CONNECTIONS];
	int listCheck[MAX_CONNECTIONS] = {0, 0, 0, 0};
	int dummy = 0;
	// This function reads server info and user credentials
	readDfcconfig(1);
	// This function create four sockets reading the address from the dsc.conf
	createMultipleSockets();

	char *subFolder;
	int i;
	int option = 0;
	char getFileName[20];
	char putFileName[20];
	int n;
	FILE *f1;
	int j;
	int ack_putfile;
	int md5sumIndex;
	int finalIndex;
	char *val1;
	char subfolder[50];
	char fileNameList[10];
	while(1)
	{
		//
		option = user_commands(); // selecting the command received
		// sending the chosen option to all the servers
		// also collect information of which servers are active
		for (i=0;i<MAX_CONNECTIONS;i++)
		{//sending the option
			int n = send(sockfd[i], (void *)&option, sizeof(int), 0);
			if (n < 0)
			{
				sendFailedArray[i] = TRUE;
				printf("Writing to socket: option sending failed at server %d", i);
			}
			else
			{
				sendFailedArray[i] = FALSE;
				printf("\nServer %d is up and running\n",i);
			}
		}
		// Sending the command to server based on the option received
		int j;
		int dummy = 100;
		switch(option)
		{
			// This command gets the file from server
			case GET_FILE:

					// collect information of which servers are active
					// sending the dummy command to all the servers
			printf("\n*************************\nEntered the get file section\n");
					for (i=0;i<MAX_CONNECTIONS;i++)
					{
						int n = send(sockfd[i], (void *)&dummy, sizeof(int), 0);
						if (n < 0)
						{
							sendFailedArray[i] = TRUE;
							printf("Server %d is down",i);
						}
						else
						{
							sendFailedArray[i] = FALSE;
							printf("\nServer %d is ready", i);
						}
					}
				// choosing the filename
				printf("\n\nEnter the file name:");
				scanf("%s", getFileName);
				printf("\nEnter the subfolder:");
				scanf("%s", subfolder);
				printf("The file name entered is %s\n", getFileName);
				printf("The subfolder is %s\n", subfolder);
			    int serverToUse[MAX_CONNECTIONS ] = {-1,-1,-1,-1};
			    if (!sendFailedArray[0]) // if server alive
			    {
			    	serverToUse[0] = 1;
			    	if (!sendFailedArray[2])
			    	//get from 0 and 2
			    	{
			    		serverToUse[2] = 1;
			    		printf("COMPLETE 1\n");
			    	}
			    	else
			    	{
			    		if (!sendFailedArray[1] && !sendFailedArray[3])
			    		{
			    			serverToUse[1] = 1;
			    			serverToUse[3] = 1;
			    		}
			    		else
			    		{
			    			printf("INCOMPLETE 1\n");
			    		}
			    	}
			    }
			    else if (!sendFailedArray[1])
			    {
			    	serverToUse[1] = 1;
			    	if (!sendFailedArray[3])
			    	//get from 1 and 3
			    	{
			    		printf("COMPLETE 2\n");
			    		serverToUse[3] = 1;
			    	}
			    	else
			    	{
			    		printf("INCOMPLETE 2\n");
			    	}
			    }
			    else
			    {
			    	printf("INCOMPLETE 3\n");
			    }

			    for (i =0;i<MAX_CONNECTIONS;i++)
			    {
			    	printf("\n\nServer %d can be used\n",i);
			    }

			    // sending packet to notify server to start or not
			    printf("\n\nSignalling the servers to start sending...\n\n");
			    int youCanSart;
			    for (i=0;i<MAX_CONNECTIONS;i++)
			    {
			    	if (serverToUse[i] == 1)
			    	{
			    		youCanSart = TRUE;
		    			n = send(sockfd[i], (void *)&youCanSart, sizeof(int), 0);
						if (n < 0)
						{
							perror("option sending failed");
						}
					}

			    	else
			    	{
			    		youCanSart = FALSE;
		    			n = send(sockfd[i], (void *)&youCanSart, sizeof(int), 0);
						if (n < 0)
						{
							perror("option sending failed");
						}
					}
				}


			    for (i = 0; i< MAX_CONNECTIONS; i++)
			    {
			    	if (serverToUse[i] == 1)
			    	{


			    		if (sendUserDetails(sockfd[i])){
			    			// receiving file 1
			    			printf("Checking for authentication before sending...\n");
					    	n = send(sockfd[i], getFileName, 50, 0);
							if (n < 0)
							{
								perror("option sending failed");
							}
              printf("\n[check1]Requested file name:%s\n",getFileName);
							receive_func(sockfd[i], getFileName, servAddr[i], servlen[i], subfolder);
							// receiving file 2
							n = send(sockfd[i], getFileName, 50, 0);
							if (n < 0)
							{
								perror("option sending failed");
							}
							receive_func(sockfd[i], getFileName, servAddr[i], servlen[i], subfolder);
						}

					}

				}
//COMEBACKHERE
				// restoring the serverToUse values
				for (i = 0;i<MAX_CONNECTIONS;i++)
				{
					serverToUse[i] = -1;
				}
				printf("Concatenating file names for received...\n");
				// start of concatenation
			    char fileLs[100];
    			char systemLSgetFiles[100];
    			char decryptSystemCmd[300];
    			bzero(systemLSgetFiles, sizeof(systemLSgetFiles));
			    strncpy(systemLSgetFiles, "ls -a ", strlen("ls -a ")); // ls
			    strncat(systemLSgetFiles, getFileName, strlen(getFileName)); // ls [filename]
			    strncat(systemLSgetFiles, "*_received", strlen("*_received"));
			    char fileList[4][100];
			    FILE *f = popen(systemLSgetFiles, "r");
			    int i = 0;
			    while (fgets(fileLs, 100, f) != NULL) {
			    	bzero(fileList[i], sizeof(fileList[i]));

					strtok(fileLs,"  \t\n");
					strncpy(fileList[i], fileLs, sizeof(fileLs));
			        printf( "%s %d\n", fileList[i], strlen(fileList[i]) );
			        i++;
			    }
			    pclose(f);
			    bzero(decryptSystemCmd, sizeof(decryptSystemCmd));
			    readDfcconfig(0);

			    // Decryption
			    printf(".\n.\n.\nDecrypting...\n");
		    	char catCommand[300];
		    	for(i=0;i<MAX_CONNECTIONS;i++)
		    	{
		    		printf("fileList[%d]: %s\n",i, fileList[i] );
		    		sprintf(decryptSystemCmd,"openssl enc -d -aes-256-cbc -in %s -out de%s -k %s", fileList[i], fileList[i], PASSWORD);
            system(decryptSystemCmd);

		    	}

		    	// concat the decrypted files
		    	sprintf(catCommand,"cat de%s de%s de%s de%s > %s_received", fileList[0],fileList[1],fileList[2],fileList[3], getFileName);
		    	system(catCommand);
		    	bzero(catCommand, sizeof(catCommand));
          sprintf(catCommand,"rm %s %s %s %s", fileList[0], fileList[1], fileList[2], fileList[3]);
          system(catCommand);

			    bzero(decryptSystemCmd,sizeof(decryptSystemCmd));
				for (i=0;i<MAX_CONNECTIONS;i++)
				{
					bzero(fileList[i],sizeof(fileList[i]));
				}

				printf("Exiting get function\n");
				break;

			case PUT_FILE:

				printf("Enter the file name:\n");
				scanf("%s", putFileName);
				printf("Enter the subfolder:\n");
				scanf("%s", subfolder);

				//IN CASE FILE IS NOT AVAILABLE TO PUT
				while(1)
			    {
			    	if (!(f1 = fopen(putFileName, "r")))
			    	{
			   			perror("fopen");
						printf("These are the list of files in your folder\n");
			    		system("ls");
			    		printf("Re enter the file name\n");
			    		scanf("%s", putFileName);
			    	}

			    	else{
			    		break;
			    	}
			    }

			    // computes the md5sum of the file and is excuted if the valid filename is entered
			    computeMd5sum(putFileName, md5sum);
				md5sumInt = md5sum[strlen(md5sum)-1] % 4;
				printf("The md5usm hash value: %d\n", md5sumInt);
				md5sumIndex = (4-md5sumInt)%4;
				printf("The md5sum index is: %d\n",md5sumIndex );
			    char systemCommand[150];
			    char filename[100];
			    bzero(filename, sizeof(filename));
			    strncpy(filename,putFileName,sizeof(putFileName));

			    strncpy(filename, putFileName,strlen(putFileName));
			    sprintf(systemCommand,"split -n 4 -a 1 -d %s en%s",putFileName, putFileName);

			    printf("%s\n", systemCommand);
			    system(systemCommand);

			    printf("Dividing done\n\n");
			    printf("Starting Encryption...\n");
			    char encryptSystemCmd[200];
			    bzero(encryptSystemCmd,sizeof(encryptSystemCmd));
			    readDfcconfig(0);
			    for (i=0;i<MAX_CONNECTIONS;i++)
			    {
			    	sprintf(encryptSystemCmd,"openssl enc -aes-256-cbc -in en%s%d -out %s%d -k %s", putFileName,i, putFileName, i, PASSWORD);
			    	system(encryptSystemCmd);
			    	printf("%s\n", encryptSystemCmd);
			    }

			    char filenameWithIndex[4][100];
			    char fileIndex[1];

			    	for (i = 0; i< MAX_CONNECTIONS; i++)
			    {
			    	if (!sendFailedArray[i])
			    	{
				    	if (sendUserDetails(sockfd[i]))
				    	{
					    	finalIndex = (i+md5sumIndex)%4;
					    	printf("%d  %d\n", finalIndex, (finalIndex+1)%4);
					    	strncpy(filenameWithIndex[finalIndex], putFileName, sizeof(putFileName));
					    	sprintf(fileIndex,"%d",finalIndex);
					    	printf("fileIndex  :   %s\n", fileIndex);
					    	strncat(filenameWithIndex[finalIndex], fileIndex, 1);
					    	printf("filename %s\n", filenameWithIndex[finalIndex]);

							send_func(sockfd[i], filenameWithIndex[finalIndex], servAddr[i], subfolder);
							sleep(1);
							// second file
							strncpy(filenameWithIndex[(finalIndex+1)%4], putFileName, sizeof(putFileName));
					    	sprintf(fileIndex,"%d",(finalIndex+1)%4);
					    	printf("fileIndex  :   %s\n", fileIndex);
					    	strncat(filenameWithIndex[(finalIndex+1)%4], fileIndex, 1);
					    	printf("filename %s\n", filenameWithIndex[(finalIndex+1)%4]);
							send_func(sockfd[i], filenameWithIndex[(finalIndex+1)%4], servAddr[i], subfolder);

							bzero(filenameWithIndex[finalIndex], sizeof(filenameWithIndex[finalIndex]));
							bzero(filenameWithIndex[(finalIndex+1)%4], sizeof(filenameWithIndex[(finalIndex+1)%4]));
							bzero(fileIndex, sizeof(fileIndex));
						}
					}
				}

				break;

			// This command gets the list of files form the server in its current directory
			case LIST_FILES:
				system("rm .list0_received .list1_received .list2_received .list3_received");
				printf("Enter the subfolder\n");
				scanf("%s", subfolder);

				int status =0;
				int checkNoCnnections = 0;
				for (i =0; i<MAX_CONNECTIONS;i++)
				{
					sprintf(fileNameList, "list%d", i);

					if (!sendFailedArray[i])
					{
						if (sendUserDetails(sockfd[i]))
			    		{

							n = send(sockfd[i], fileNameList, 50, 0);
							if (n < 0){
								perror("option sending failed");
							}

							status = receive_func(sockfd[i], fileNameList, servAddr[i], servlen[i], subfolder);
							if (status == 0)
							{
								checkNoCnnections++;
							}

						}

					}
					bzero(fileNameList, sizeof(fileNameList));
				}

				if (checkNoCnnections == 3)
				{
					printf("ALL SERVERS CLOSED\n");
				}
		        // creating files if not present

		        system("touch .list0_received");
		        system("touch .list1_received");
		        system("touch .list2_received");
		        system("touch .list3_received");
		        // concat the files present
		        system("cat .list0_received .list1_received .list2_received .list3_received > temp_list");
		        system("sort temp_list | uniq > final_list");

		        FILE *fp;
		        char Buf[200];
		        char *val1;
		        char array[256][256];
		        char array2[256][256];
		        char necessary_files[256][256];

		        // checking the various files and displaying their status
		        int p = 0, q = 0;

		        FILE *fr;
				fr = fopen("final_list","r");
                if (fr != NULL)
                {
                    char line_string[500];
                    int i = 0;
                    char filename_string[500];
                    char filename_string1[500];
                    int subfile_count = 0;
                    while(fgets(line_string, sizeof(line_string), fr) != NULL)
                    {
                        //if(strncmp(line_string,".",strlen(".")) == 0)
                        //{
                            if(strlen(line_string)>3)
                            {
                                char *line_ptr;
                                line_ptr = (char *)line_string;
                                //line_ptr = line_ptr + strlen(".");
                                if (subfile_count == 0)
                                {
                                    bzero(filename_string,sizeof(filename_string));
                                    memcpy(filename_string,line_ptr,strlen(line_ptr)-2);
                                }
                                bzero(filename_string1,sizeof(filename_string1));
                                memcpy(filename_string1,line_ptr,strlen(line_ptr)-2);
                                if(strcmp(filename_string,filename_string1) == 0)
                                {
                                    subfile_count = subfile_count +1;
                                    if(subfile_count == 4)
                                        printf("%s [COMPLETE]\n",filename_string);
                                }
                                else
                                {
                                    if(subfile_count != 4)
                                        printf("%s [INCOMPLETE]\n",filename_string);
                                    subfile_count = 1;
                                    strcpy(filename_string,filename_string1);

                                }
                            }
                    }
                    if(subfile_count != 4)
                        printf("%s [INCOMPLETE]\n",filename_string);
                }
                fclose(fr);

			break;

			default:
			break;
      exit(1);

		}
	}
	close(sockfd);
	return 0;
}
