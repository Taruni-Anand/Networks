#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/time.h>
#include <openssl/md5.h>
#include <time.h>

#define MAX_CONNECTIONS 1000
#define BYTES 1024
#define MSG_SIZE 99999
#define wsMaxSize 1000
#define GETADDRINFOERROR 1
#define BINDERROR        1
#define LISTENERROR      1
#define SLOTERROR        0
#define PORTERROR        1
#define WSCONFIGERROR    1
#define SOCKETCLOSE		 0
#define TRUE             1
#define FALSE            0
#define SUCCESS          1
#define FAIL             0
#define MAX_BUFFER_SIZE 9999

int TIMEOUT;
int listenfd, clients[MAX_CONNECTIONS];
void error(char *);
void WebServer();
void WebResponse(int sockfd, char *timeout, char *pwd);
int cache_exists(char *timeoutStr, char *pwd, int sockfd);
char PORT[10];
struct itimerval timeout;


static unsigned int get_file_size (FILE * fileDescriptor)
{
    unsigned int size;

    fseek(fileDescriptor, 0L, SEEK_END);
    size = ftell(fileDescriptor);
    fseek(fileDescriptor, 0L, SEEK_SET);

    return size;
}



void WebServer()          //setting up TCP connection
{
    struct addrinfo web_serv, *res, *p;
    memset (&web_serv, 0, sizeof(web_serv));
    web_serv.ai_family = AF_INET;
    web_serv.ai_socktype = SOCK_STREAM;
    web_serv.ai_flags = AI_PASSIVE;
    int s = 1;

    if (getaddrinfo( NULL, PORT, &web_serv, &res) != 0)
    {
        perror ("ERROR in getaddrinfo()");
        exit(GETADDRINFOERROR);
    }

    for (p = res; p!=NULL; p=p->ai_next)
    {
        if ((listenfd = socket (p->ai_family, p->ai_socktype, 0)) == -1)
        {
            continue;
        }
        if (bind(listenfd, p->ai_addr, p->ai_addrlen) == 0) break;
    }

    if (p==NULL)
    {
        perror ("socket() or bind() creation failed");
        exit(BINDERROR);
    }
    freeaddrinfo(res);
    if (setsockopt(listenfd,SOL_SOCKET,SO_REUSEADDR,&s,sizeof(int)) == -1)
    {
        printf("setsockopt error");
        exit(1);
    }
    if ( listen (listenfd, MAX_CONNECTIONS) != 0 )
    {
        perror("listen() error");
        exit(LISTENERROR);
    }
}


void file_created_at(char *pwd, char c_time[1000]) {
    struct stat attr;
    stat(pwd, &attr);
    char date[10];
    sprintf(c_time,"%s",ctime(&attr.st_mtime));

}

//code from stackoverflow.com
char *computeMD5(const char *str, int length)
{
    int n;
    MD5_CTX c;
    unsigned char digest[16];
    char *out = (char*)malloc(33);
    MD5_Init(&c);
    while (length > 0) {
        if (length > 512) {
            MD5_Update(&c, str, 512);
        } else {
            MD5_Update(&c, str, length);
        }
        length -= 512;
        str += 512;
    }
    MD5_Final(digest, &c);
    for (n = 0; n < 16; ++n) {
        snprintf(&(out[n*2]), 16*2, "%02x", (unsigned int)digest[n]);
    }
    return out;
}


#define FILE_SIZE 1000000

void prefetch(char * pwd, int sockfd)
{
    printf("\nPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP\n");
    char bufTosend[FILE_SIZE];
    char filepath[MAX_BUFFER_SIZE];
    char prefeReq[MAX_BUFFER_SIZE];
    char buffer[MAX_BUFFER_SIZE];
    int readFile,n;
    char check[MAX_BUFFER_SIZE];
    int i,openFile;
    char *md5;
    int flag;
    FILE *fp;
    char newVar[MAX_BUFFER_SIZE];
    char * ret;
    char *retVal;
    char path[MAX_BUFFER_SIZE];
    struct sockaddr_in host_addr;
    struct hostent* host;
    int p=9;

    bzero(bufTosend,sizeof(bufTosend));
    bzero(filepath,sizeof(filepath));
    bzero(prefeReq,sizeof(prefeReq));
    bzero(check,sizeof(check));
    bzero(newVar,sizeof(newVar));
    bzero(path,sizeof(path));
    bzero(buffer,sizeof(buffer));

    openFile=open(pwd,O_RDONLY);
    if(openFile==-1){
        printf("\n Error in opening the file");
    }

    // reading file
    readFile = read(openFile,bufTosend, sizeof bufTosend);
    if (readFile < 0)
    {
        printf("Error in reading the file\n");
    }

    char *newPtr;

    // check if href is present
    if((ret=strstr(bufTosend,"href=\"http://"))!= NULL){
        while((ret=strstr(ret,"href=\"http://")) ){
            ret = ret+13;
            i=0;
          printf("\nExtracting the http URL...\n");
            // extracting the http url after href command
            while(*ret!='"')
                {
                    newVar[i] = *ret;
                    printf("%c",*ret);
                    ret++;
                    i++;
                }
            newPtr=ret;
            newVar[i]='\0';

            // computing the md5sum of the file
            strcpy(check, newVar);
            md5 = computeMD5(check,strlen(check));
            strcpy(filepath,"./cachedir/");
            strcat(filepath,md5);
            strcat(filepath,".html");
            printf("\nPath of requested path: %s",filepath);
            retVal = strstr(newVar,"/");
            if ( retVal == NULL){
              continue;
            }
            if(retVal!=NULL){
                strcpy(path,retVal);
            }

            *retVal='\0';
            ret =newPtr +1;

            printf("\nGET %s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n\r\n",path,newVar);
            sprintf(prefeReq,"GET %s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n\r\n",path,newVar);

            // sending request to server
            n = send(sockfd,prefeReq,strlen(prefeReq),0);
            printf("\nSending request to the server...");

            fp=fopen(filepath,"w");
            do{
                n=recv(sockfd,buffer,500,0);
                fwrite(buffer,1,n,fp);
            }while(n>0);

            memset(pwd,0,0);
        }
    }


}


int COUNT = 0;

void WebResponse(int sockfd, char *timeout, char *pwd)
{
    int cache;

    char client_buff[MAX_BUFFER_SIZE];
    char server_buff[MAX_BUFFER_SIZE];
    char method[MAX_BUFFER_SIZE];
    char path[MAX_BUFFER_SIZE];
    char http_ver[MAX_BUFFER_SIZE];
    char host_request[MAX_BUFFER_SIZE];
    char md5sum[100];
    char website[MAX_BUFFER_SIZE];
    char *url = NULL;
    char *websiteWithSlash = NULL;
    char *websiteWithSlash1;
    char buff[MAX_BUFFER_SIZE];
    struct hostent *hostToconnect;
    struct sockaddr_in hostAddr;
    int on = 1;
    int cache_flag;

    int hfd;
    int nbytes,sbytes;
    int len;

    char filename[MAX_BUFFER_SIZE];
    FILE *fileProxy;


    bzero(client_buff, sizeof(client_buff));
    bzero(method, sizeof(method));
    bzero(path, sizeof(path));
    bzero(http_ver, sizeof(http_ver));
    bzero(website, sizeof(website));
    bzero(md5sum, sizeof(md5sum));


    char Invalid_Method[MAX_BUFFER_SIZE] = "<html><body><H1>Error 400 Bad Request: Invalid Method </H1></body></html>";
    char Invalid_version[MAX_BUFFER_SIZE] =  "<html><body><H1>Error 400 Bad Request: Invalid HTTP Version</H1></body></html>";

    if (read(sockfd, client_buff, MAX_BUFFER_SIZE)<0)
    {
        printf("recieve error\n");
    }

    else
    {
        sscanf(client_buff,"%s %s %s",method,path,http_ver);
        printf("Recieved Request: %s %s %s\n",method,path,http_ver);

        if (strncmp(method,"GET",strlen("GET")) != 0)
        {
            write(sockfd,Invalid_Method,strlen(Invalid_Method));
            printf("Invalid Request method\n");
            exit(1);
        }

        else
        {
            int i=0;
            websiteWithSlash= strstr(path,"//");
            websiteWithSlash+=2;

            for(i=0;i<strlen(websiteWithSlash);i++)
            {
                if(websiteWithSlash[i]=='/')
                    break;
                website[i]=websiteWithSlash[i];
            }
            url=strstr(websiteWithSlash,"/");

            MD5_CTX mdContext;
            MD5_Init(&mdContext);
            MD5_Update (&mdContext, path, strlen(path));
            MD5_Final (md5sum, &mdContext);

            for (i = 0; i< MD5_DIGEST_LENGTH; i++)
            {
                sprintf(&buff[2*i],"%02x", md5sum[i]);
            }


            sprintf(filename,"%s.html",buff);
            printf("Cache stores this as: %s\n", buff);
            sprintf(pwd,"%s%s",pwd, filename);

            // find if the file is present in cache or not
            cache_flag = cache_exists(timeout, pwd, sockfd);


            if (cache_flag == FAIL)   //connecting to server when cache not present
            {
                printf("No cache found...\n\n");
                printf("Extracting file from host server...\n");
                fileProxy = fopen(pwd,"ab");
                if (fileProxy < 0)
                {
                    perror("Error in opening file");
                }
                hostToconnect = gethostbyname(website);
                if (!hostToconnect)
                {
                    perror("Inavlid host address");
                    exit(1);
                }

                bzero(&hostAddr,sizeof(hostAddr));                    //zero the struct
                hostAddr.sin_family = AF_INET;                   //address family
                hostAddr.sin_port = htons(80);        //htons() sets the port # to network byte order
                memcpy(&hostAddr.sin_addr, hostToconnect->h_addr, hostToconnect->h_length);
                len = sizeof(hostAddr);
                hfd = socket(AF_INET, SOCK_STREAM, 0);
                if (hfd<0)
                {
                    perror("Socket creation failed");
                }
                setsockopt(hfd, SOL_SOCKET, SO_REUSEADDR, &on, 4);

                int skt = connect(hfd, (struct sockaddr *) &hostAddr, len);
                if (skt < 0)
                {
                    printf("Connection problem\n");
                    close(hfd);
                }

                if (url != 0)
                    sprintf(host_request,"GET %s %s\r\nHost: %s\r\nConnection: close\r\n\r\n",url,http_ver,website);
                else
                    sprintf(host_request,"GET / %s\r\nHost: %s\r\nConnection: close\r\n\r\n",http_ver,website);
                printf("Request from host: %s\n", host_request);

                nbytes = send(hfd,host_request,sizeof(host_request),0);

                if (nbytes < 0)
                {
                    perror("Host send failed");
                }

                else
                {
                    printf("\n\nSarted sending file from server...\n\n");
                    do{
                        bzero((char*)server_buff,MAX_BUFFER_SIZE);
                        nbytes=recv(hfd,server_buff,sizeof(server_buff),0);        // receiving from host server
                        if(!(nbytes<=0))
                        {
                            send(sockfd,server_buff,nbytes,0);                                 // sending to client
                            fwrite(server_buff,1,nbytes,fileProxy);
                        }
                    }while(nbytes>0);
                    printf("\n\nStarting the Prefetching operation... \n\n");
                    prefetch(pwd,hfd);
                }

                fclose(fileProxy);
            }
        }
    }
    bzero(Invalid_version,sizeof(Invalid_version));
    bzero(Invalid_Method,sizeof(Invalid_Method));
    close(sockfd);
    close(hfd);
}

int cache_exists(char *timeoutStr, char *pwd, int sockfd)
{
    int timeout = atoi(timeoutStr);
    char c_time[1000];
    int nbytes;
    char bufTosend[MAX_BUFFER_SIZE];
    file_created_at(pwd, c_time);
    FILE *fd;

    if( access( pwd, F_OK ) != -1 )
    {
        // file available
        char *hours, *minutes,*seconds;
        int hoursInt, minutesInt, secondsInt;
        hours = strtok(c_time,":") ;
        minutes = strtok(NULL,":") ;
        seconds = strtok(NULL,":") ;
        seconds = strtok(seconds, " ");
        hours = strtok(hours," ") ;
        hours = strtok(NULL," ");
        hours = strtok(NULL," ");
        hours = strtok(NULL," ");

        int fileTime = atoi(hours)*3600 + atoi(minutes)*60 + atoi(seconds);

        time_t current_time;
        time(&current_time);
        bzero(c_time,sizeof(c_time));

        sprintf(c_time,"%s", ctime(&current_time));
        printf("Current Time:%s\n", c_time);

        hours = strtok(c_time,":") ;
        minutes = strtok(NULL,":") ;
        seconds = strtok(NULL,":") ;
        seconds = strtok(seconds, " ");
        hours = strtok(hours," ") ;
        hours = strtok(NULL," ");
        hours = strtok(NULL," ");
        hours = strtok(NULL," ");

        int presentTime = atoi(hours)*3600 + atoi(minutes)*60 + atoi(seconds);
        printf("Present time: %d\n", presentTime);
        printf("File time: %d \n", fileTime);

        if (presentTime - fileTime > timeout)
        {
            printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\nTimed out\n");
            return FAIL;
        }

        else
        {
            printf("\n******************************************\nFile sent from cache...\n");
            bzero(bufTosend,sizeof(bufTosend));
            printf("Sending cached file\n");
            fd=fopen(pwd,"r");

            do{
                nbytes = fread(bufTosend,1,MAX_BUFFER_SIZE,fd);
                send(sockfd,bufTosend,nbytes,0);
            }
            while(nbytes>0);

            fclose(fd);
            close(sockfd);
            return SUCCESS;

        }
    }

    else
    {
        return FAIL;
    }


}

//code from http://blog.abhijeetr.com/2010/04/very-simple-http-server-writen-in-c.html
int main(int argc, char* argv[])
{
    char pwd[MAX_BUFFER_SIZE];  // Current working direcroty
    char timeout[10];
    int sock_n;
    if (argc<3)
    {
        printf("Invalid arguements: ./webproxy <port_num> <Cache Timeout>\n");
        exit(1);
    }
    printf("\\m/(-_-)\\m/\\m/(-_-)\\m/\\m/(-_-)\\m/\\m/(-_-)\\m/");
    printf("\nWeb Proxy Server");
    printf("\nPort number: %s\n", argv[1]);
    printf("Cache Timeout: %s\n\n", argv[2]);

    strcpy(PORT,argv[1]);
    strcpy(timeout,argv[2]);

    int pid;
    int connectionNum=0;
    int i;

    struct sockaddr_in clientAddr;
    socklen_t addrlen;
    char c;

    char parentdir[MAX_BUFFER_SIZE];
    char cmdCreateCache[MAX_BUFFER_SIZE];

    if (getcwd(parentdir, sizeof(parentdir)) != NULL)
    {
        sprintf(pwd,"%s/cache/",parentdir);
        sprintf(cmdCreateCache,"mkdir -p %s",pwd);
        system(cmdCreateCache);
    }

    for (i=0; i<MAX_CONNECTIONS; i++)
    {
        clients[i]=-1;
    }

    int port_num = atoi(PORT);

    if (port_num < 1024)
    {
        fprintf(stderr, "The port number chosen is %d and is invalid\n", port_num);
        exit(PORTERROR);
    }

    WebServer();
    int connectionCount = 0;
    while (1)
    {
        addrlen = sizeof(clientAddr);
        clients[connectionNum] = accept (listenfd, (struct sockaddr *) &clientAddr, &addrlen);

        if (clients[connectionNum]<0)
            error ("accept() error");
        else
        {
            printf("\n****************************************\nConnection No.%d   \n\n", connectionCount++);
        }
            pid = fork();
            if (pid <0)
                printf("Error on Fork !!");

            if (pid == 0)
            {
                WebResponse(clients[connectionNum], timeout, pwd);
                close(listenfd);
                exit(0);
            }

    }

    return 0;
}
