#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include <ctype.h>

#define EOL "\r\n"
#define EOL_SIZE 2

char** split(const char *str, const char *delimiter, size_t *len){				//splitting the string into words
    char *text, *p, *first, **array;
    int c;
    char** ret;

    *len = 0;
    text=strdup(str);//strdup not standard
    if(text==NULL) return NULL;
    for(c=0,p=text;NULL!=(p=strtok(p, delimiter));p=NULL, c++)//count item
        if(c==0) first=p; //first token top

    ret=(char**)malloc(sizeof(char*)*c+1);//+1 for NULL
    if(ret==NULL){
        free(text);
        return NULL;
    }
    //memmove?
    strcpy(text, str+(first-text));//skip until top token
    array=ret;
    for(p=text;NULL!=(p=strtok(p, delimiter));p=NULL){
        *array++=p;
    }
    *array=NULL;
    *len=c;
    return ret;
}

char **words;
size_t len=0;

int populate_wsconf_tokens(void){
	char file_contents[1000],*ptr=NULL;
	long input_file_size;
	FILE *input_file = fopen("ws.conf", "rb");
	fseek(input_file, 0, SEEK_END);
	input_file_size = ftell(input_file);
	rewind(input_file);
	char c;
	int i=0;
	do{
		c=fgetc(input_file);
		//printf("%c\t",c );
		file_contents[i]=c;
		i++;
	}while(c!=EOF);

	fclose(input_file);
	//printf("%s\n",file_contents );

	words = split(file_contents, " \n", &len);

	for(i = 0;i<len-1;++i){
	    strcat(file_contents, words[i]);
	    //printf("%s\n",words[i] );
	}
	return i;
}


int get_file_size(int fd) {
 struct stat stat_struct;
 if (fstat(fd, &stat_struct) == -1)
 	return (1);
 return (int) stat_struct.st_size;
}

void send_new(int fd, char *msg) {
 int len = strlen(msg);
 if (write(fd, msg, len) == -1) {
 	printf("Error in send\n");
 }
}

int recv_new(int fd, char *buffer) {
	char *p = buffer; // Use of a pointer to the buffer rather than dealing with the buffer directly
	int eol_matched = 0; // Use to check whether the recieved byte is matched with the buffer byte or not
 	while (recv(fd, p, 1, 0) != 0) // Start receiving 1 byte at a time
 	{
	  if (*p == EOL[eol_matched]) // if the byte matches with the first eol byte that is '\r'
	  	{
	   		++eol_matched;
	   		if (eol_matched == EOL_SIZE) // if both the bytes matches with the EOL
	   		{
	    		*(p + 1 - EOL_SIZE) = '\0'; // End the string
	    		return (strlen(buffer)); // Return the bytes recieved
	   		}
	  	} 
	  	else {
	   		eol_matched = 0;
	  	}
	  p++; // Increment the pointer to receive next byte
	}
	return (0);
}

/*error 404: file not found
error 400: Bad request
error 501: Not implemented
error 500: Internal Server Error*/ 

void error_404(int fd){
	char errormsg[]="HTTP/1.1 404 Not Found\r\n\r\n<html><head><title>404 Not Found Reason URL does not exist :<<requested url>></head></title></html>";
	write(fd, errormsg, strlen(errormsg)-1);
	sleep(1);
}

void error_400_method(int fd, char msg[]){
	char errormsg[]="HTTP/1.1 400 Bad Request\r\n\r\n<html><body>400 Bad Request Reason: Invalid Method :";
	write(fd, errormsg, strlen(errormsg)-1);
	char method[]="</body></html>";
	write(fd, msg, strlen(msg)-1);
	write(fd,method,strlen(method)-1);
	sleep(1);
}

void error_400_URL(int fd, char msg[]){
	char errormsg[]="HTTP/1.1 400 Bad Request\r\n\r\n<html><body>400 Bad Request Reason: Invalid URL :";
	write(fd, errormsg, strlen(errormsg)-1);
	char method[]="</body></html>";
	write(fd, msg, strlen(msg)-1);
	write(fd,method,strlen(method)-1);
	sleep(1);
}

void error_400_version(int fd, char msg[]){
	char errormsg[]="HTTP/1.1 400 Bad Request\r\n\r\n<html><body>400 Bad Request Reason: Invalid HTTP version :";
	write(fd, errormsg, strlen(errormsg)-1);
	char method[]="</body></html>";
	write(fd, msg, strlen(msg)-1);
	write(fd,method,strlen(method)-1);
	sleep(1);
}

void error_501(int fd, char msg[]){
	char errormsg[]="HTTP/1.1 501 Not Implemented\r\n\r\n<html><head><title>404 Not Implemented :";
	char method[]="</head></title>";
	write(fd, errormsg, strlen(errormsg)-1);
	write(fd, msg, strlen(msg)-1);
	write(fd, method, strlen(method)-1);
	sleep(1);
}

void error_500(int fd){
	char errormsg[]="HTTP/1.1 500 Internal Server Error\r\n\r\n<html><head><title>500 Internal Server Error: Cannot allocate memory</head></title>";
	write(fd, errormsg, strlen(errormsg)-1);
	sleep(1);
}


int connection(int fd) {
	int size_of_words=populate_wsconf_tokens();
	char request[500], resource[500], *ptr;
 	int fd1, length;
 	if (recv_new(fd, request) == 0) {
	  	printf("Recieve Failed\n");
	}
	printf("%s\n", request);
	// Check for a valid browser request
	ptr = strstr(request, " HTTP/");
	if (ptr == NULL) {
	  	printf("NOT HTTP !\n");
	  	error_400_version(fd,request);
	} 
	else {
		*ptr = 0;
	  	ptr = NULL;

	  	if (strncmp(request, "GET ", 4) == 0) {
	   		ptr = request + 4;
	  	}else{
	  		if (ptr==NULL){
	  			printf("Bad Request\n");
	  			error_400_method(fd,request);
	  		}else{
	  			error_501(fd,request);
	  		}
	  	}
	  	if (ptr == NULL) {
	   		printf("Bad Request ! \n");
	   		error_400_URL(fd,request);
	  	} else {
	   		if (ptr[strlen(ptr) - 1] == '/') {
	   			strcat(ptr, "index.html");
   			}
   		//printf("%d",size_of_words);
   		for (int j=0;j<=size_of_words;j++){
   			if (strncmp("Documentroot\t",words[j],12)==0){
   				//printf("%s\n",words[j] );
   				strcpy(resource,words[j+1]);
   				//printf("%s\n",resource );
   				break;	
   			}	
   		}
   		

		int j = 0;
		for (int i = 0; i < strlen(resource); i++)		//removing quotes and cleaning the root
		{
		    if (resource[i] == '/')
		    {
		        resource[j++] = resource[i++];
		        resource[j++] = resource[i];
		        if (resource[i] == '\0')
		            break;
		    }
		    else if (resource[i] != '"')
		        resource[j++] = resource[i];
		}
		resource[j] = '\0';
		char content_type[12];
   		strcat(resource, ptr);
   		printf("%s\n",resource );
   		char* s = strchr(ptr, '.');
   		int i,type_index;
   		for(i=0;i<=size_of_words;i++){
   			if (strncmp(s,words[i],3)==0){
   				strcpy(content_type,words[i+1]);
   				break;
   			}
   		}
   		//type_index=3;
   		for (i = type_index; i<=size_of_words; i+=2) {
     			fd1 = open(resource, O_RDONLY, 0);
     			printf("Opening \"%s\"\n", resource);
     			if (fd1 == -1) {
			      printf("404 File not found Error\n");
			      error_404(fd);
     			}else {
     				length=get_file_size(fd1);
     				 char str[12];
				sprintf(str, "%d", length);
			      printf("HTTP 1.1 200 OK\n\nContent-Type: %s\n\nContent-Size: %s\n\n",
			        content_type,str);
			      send_new(fd, "HTTP/1.1 200 OK\r\n");
			      send_new(fd, "Content-Type:");
			      send_new(fd, content_type);		     
    			send_new(fd,"\n\nContent-Size:");
    			send_new(fd, str);
    			send_new(fd,"\n\n");
			      if (ptr == request + 4) // if it is a GET request
			        {
			       		if ((length = get_file_size(fd1)) == -1)
			        		printf("Error in getting size !\n");
			       		size_t total_bytes_sent = 0;
			       		ssize_t bytes_sent;
			       		while (total_bytes_sent < length) {
			        //Zero copy optimization
			        		if ((bytes_sent = sendfile(fd, fd1, 0,length - total_bytes_sent)) <= 0) {
			         			if (errno == EINTR || errno == EAGAIN) {
			          				continue;
			         			}
			         			perror("sendfile");
			         			return -1;
			         			sleep(1);
			        		}
			        	total_bytes_sent += bytes_sent;
			       	}
			    }
			}
     	break;
}
sleep(1);
   close(fd);
  }
 }

 shutdown(fd, SHUT_RDWR);
}



int main(int argc, char *argv[]) {
	int size_of_words=populate_wsconf_tokens();
	//list of strings that contain the tokens in ws.conf
	int sockfd, newsockfd, portno, pid;
	socklen_t clilen;
	struct sockaddr_in serv_addr, cli_addr;

	//OBTAIN PORT NUMBER FROM WORDS ARRAY

	for (int j=0;j<size_of_words;j++){
		if (strncmp(words[j],"Listen",6)==0){
			portno=atoi(words[j+1]);
			break;
		}
		else
			printf("No port number provided");
	}

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
	 	error("ERROR opening socket");
	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(portno);
	if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
	  	error("ERROR on binding");
	listen(sockfd, 5);
	clilen = sizeof(cli_addr);
	 /*
	  Server runs forever, forking off a separate
	  process for each connection.
	  */
	while (1) {
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
	  	if (newsockfd < 0)
	   		error("ERROR on accept");
	  	pid = fork();
	  	if (pid < 0)
	   		error("ERROR on fork");
	  	if (pid == 0) {
	   		close(sockfd);
	   		connection(newsockfd);
	   		exit(0);
	  	} else
	   		close(newsockfd);
	} /* end of while */
	close(sockfd);
	return 0; /* we never get here */
}

