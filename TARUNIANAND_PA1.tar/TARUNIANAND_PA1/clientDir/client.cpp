#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <stdlib.h>
#include <memory.h>
#include <errno.h>
#include <time.h>
#include <math.h>

#define MAXBUFSIZE 1048576		//10MB
#define BUFSIZE 500			// 10kB


struct packet
{
	int c_Id;
	char filename[100];
	unsigned char data[BUFSIZE];
	int dataSize;
};

size_t getFileSize(FILE *file) {
	fseek(file, 0, SEEK_END);
  	size_t file_size = ftell(file);
  	return file_size;
}

int getTotalNumberOfPackets(size_t file_size) {

	int packets = file_size/BUFSIZE;
  	if (file_size % BUFSIZE > 0) {
  		packets++;
  	}
  	return packets;
}

int power(int x, int y)
{
	for (int i=0; i<y; i++)
	x*=y;
	return x;
}

int getClientID() {
	srand (time(NULL));
  	int c_Id = 0;
  	int i = 0;
  	while(i<4){
  		c_Id = c_Id * power(10, i) + (char)(rand() % 10 + 1);
  		i++;
  	}
  	printf("ID%d\n", c_Id);
  	return c_Id;
}

long unsigned int getBufferContentSize(unsigned char buffer[]) {
	long unsigned int buffSize = 0;

	while (buffer[buffSize] != '\0') {
		buffSize++;
	}

	return buffSize+1;
}

int main (int argc, char * argv[])
{



	int nbytes;                             // number of bytes send by sendto()
	int sockfd;                               //this will be our socket
	char buf[BUFSIZE];
	unsigned char file_buf[BUFSIZE];
	int client = getClientID();
	struct sockaddr_in serveraddr;              //"Internet socket address structure"
	unsigned int server_length = sizeof(serveraddr);
	if (argc < 3)
	{
		printf("USAGE:  <server_ip> <server_port> \n");
		exit(1);
	}

	bzero(&serveraddr,sizeof(serveraddr));               //zero the struct
	serveraddr.sin_family = AF_INET;                 //address family
	serveraddr.sin_port = htons(atoi(argv[2]));      //sets port to network byte order
	serveraddr.sin_addr.s_addr = inet_addr(argv[1]); //sets server IP address

	//Causes the system to create a generic socket of type UDP (datagram)
	if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		printf("unable to create socket");
	}


//*******************************************MENU***********************************************************


	while(1){
		char climess[BUFSIZE];
	    /* get a message from the user */
	    bzero(buf, BUFSIZE);
	    printf("Please enter task:\n1) get \n2) put \n3) delete \n4) ls\n5)exit \n\n");
	    fgets(buf, BUFSIZE, stdin);
	    strncpy(climess,buf,sizeof(buf));

	    /* send the message to the server */
	    int serverlen = sizeof(serveraddr);
	    int n = sendto(sockfd, buf, strlen(buf), 0, (struct sockaddr*)&serveraddr, serverlen);
	    if (n < 0) 
	      perror("ERROR in sendto");

	   // bzero(buf,BUFSIZE);
	    /* print the server's reply */
	    /*if(recvfrom(sockfd, buf, sizeof(buf), 0,(struct sockaddr*)&serveraddr, (socklen_t*)&serverlen)< 0) 
	      perror("ERROR in recvfrom");
		else printf("\n\n%s",buf);
*/
//******************************************TO EXIT************************************************

	if (!strncmp(buf,"exit",4))
	  { printf("\n\n\n\n\nquitting");
	close(sockfd);
	}




//*******************************************PUT FILE*******************************************************	

	
else if (!strncmp(buf, "put", 3))
	{
	//Read a file.
	FILE *file;
	printf("Enter the file name:");
	char f[100];
	gets(f);
	
	file = fopen(f, "r");
	
	if(file == NULL)
    {
      printf("file does not exist\n");
    }

  	size_t file_size = getFileSize(file); 		//Tells the file size in bytes.
  	printf("file_size: %lu\n\n", file_size);

  	fseek(file, 0, SEEK_SET);
	//rewind(file);
  	int count = 0;
  	int totalPackets = getTotalNumberOfPackets(file_size);

  	while (count < totalPackets) {
  		printf("---START\n");
	  	int byte_read = fread(file_buf, sizeof(unsigned char), BUFSIZE, file);
	  	if( byte_read <= 0)
	    {
	      printf("unable to copy file into file_buf\n");
	      exit(1);
	    }

	    struct packet p;
	    p.c_Id = client;
	    memset(p.filename, '\0', sizeof(p.filename));
	    strcpy(p.filename,f);
		p.dataSize = byte_read;//getBufferContentSize(file_buf)-1;

	    memcpy(p.data, file_buf, sizeof(file_buf));

	    printf("CLIENT ID:%d**%d:\n\n", client, p.c_Id);
	    printf("DATA SIZE:%d:\n", p.dataSize);
	  	printf("Buffer Content:%d  %lu   %lu  %lu\n", byte_read, sizeof(file_buf), getBufferContentSize(file_buf), getBufferContentSize(p.data));
	  	printf("BUFFER:%s:\n\n", p.data);

		//**************************************ACK****************************************************

		

	    nbytes = sendto(sockfd, &p, sizeof(packet), 0, (struct sockaddr *)&serveraddr, sizeof(serveraddr));

	    if (nbytes < 0){
			printf("Error in sendto\n");
		}


	  	bzero(file_buf,sizeof(file_buf));
	    //Read a file ends
		
		int msec = 0, trigger = 2; // 10ms 
		clock_t before = clock();

		do {
 			if((nbytes = recvfrom(sockfd, buf, MAXBUFSIZE, 0, (struct sockaddr *)&serveraddr, &server_length))<0)
			{
				nbytes = sendto(sockfd, &p, sizeof(p), 0, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
	    			if (nbytes < 0){
					printf("Error in sendto\n");
						}
			}
	  
  			clock_t difference = clock() - before;				//TIMER IS SET HERE!!
  			msec = difference * 1000 / CLOCKS_PER_SEC;
  
		} while ( msec < trigger );

		
		//printf("Server says %s\n", buffer);
		count++;
		printf("END OF PACKET\n\n");
	}
	}
//******************************************GET FILE**********************************************************
else if (!strncmp(buf,"get",3)){
	FILE *file;


	//get the name of the file from client
	printf("Enter the file name:");
	char f[100];
	gets(f);
	nbytes = sendto(sockfd, f, strlen(f), 0, (struct sockaddr *)&serveraddr, sizeof(serveraddr));

		if (nbytes < 0){
			printf("Error in sendto\n");
		}


	while (1) {
		printf("---START\n");		//Start receiving file
		
 		
 		bzero(buf,sizeof(buf));
	    struct packet pack;

	    if (recvfrom(sockfd, &pack, sizeof(packet), 0, (struct sockaddr *)&serveraddr, &server_length)<0)
	    {
	    	printf("error in recieving the file\n");
	    	continue;
	    }

	    char filename[100];
	    strcpy(filename, "./clientDir/");
	    strcat(filename, pack.filename);
	    strcat(filename, "_new");

	    printf("FILENAME: %s   %s\n", filename, pack.filename);
	    file = fopen(filename,"ab");
	   
	    int c_Id = pack.c_Id;						
	    unsigned char *file_buf = pack.data;						

	    memcpy(file_buf, pack.data, pack.dataSize);
	    int fileSize = fwrite(file_buf , sizeof(unsigned char), pack.dataSize, file);

	    printf("CLIENT ID:%d:\n", pack.c_Id);
	    printf("DATA SIZE:%d:\n", pack.dataSize);
	  	printf("Buffer Content:%d  %lu   %lu  %lu\n", fileSize, sizeof(file_buf), getBufferContentSize(file_buf), getBufferContentSize(pack.data));
	  	printf("BUFFER:%s:\n\n", pack.data);

	    if( fileSize < 0)
	    {
	    	printf("error writting file\n");
	        exit(1);
	    }

		nbytes = sendto(sockfd, "file received\n", 17, 0, (struct sockaddr *)&serveraddr, server_length);
		if (nbytes < 0){
			printf("Error in sendto\n");
		}
		fclose(file);
		printf("END OF PACKET\n\n");
	}

}
//*****************************************DELETE FILE********************************************************
else if (!strncmp(buf,"delete",6))
{
	printf("\nEnter the file name:");
	char f[100];
	gets(f);
	FILE *fp;
	fp= fopen(f,"r");
	if(fp==NULL)
	{
		nbytes = sendto(sockfd, f, strlen(f), 0, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
		if (nbytes < 0)
		{
			printf("Error in sendto\n");
		}
		else
		{
			bzero(buf,sizeof(buf));
			nbytes = recvfrom(sockfd, buf, MAXBUFSIZE, 0, (struct sockaddr *)&serveraddr, &server_length);
			if (nbytes < 0)
			{
			printf("Error in recvfrom\n");
		 	}
			printf("%s",buf);	
		}
	}

	else
	{
		remove(f);
		printf("\nFile has been removed");
	}


}
//*****************************************LIST***************************************************************
else if (!strncmp(buf,"ls",2))
{
	
	nbytes = recvfrom(sockfd, buf, MAXBUFSIZE, 0, (struct sockaddr *)&serveraddr, &server_length);
	if (nbytes < 0)
	{
	printf("Error in recvfrom\n");
	}
	printf("%s\n\n",buf);
	bzero(buf,sizeof(buf));

	


}
//*******************************************END***********************************************************
else 
	{printf("Not a valid command");
	continue;
}




}//end of while

}//end of main


