#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include <time.h>
#include <dirent.h>


#define MAXBUFSIZE 2000
#define BUFSIZE 500		//10 MB

struct packet
{
	int c_Id;
	char filename[100];
	unsigned char data[BUFSIZE];
	int dataSize;
};

size_t getFileSize(FILE *file) {
	fseek(file, 0, SEEK_END);
  	size_t file_size = ftell(file);
  	return file_size;
}

int getTotalNumberOfPackets(size_t file_size) {

	int packets = file_size/BUFSIZE;
  	if (file_size % BUFSIZE > 0) {
  		packets++;
  	}
  	return packets;
}


int power(int x, int y)
{
	for (int i=0; i<y; i++)
	x*=y;
	return x;
}

int getClientID() {
	srand (time(NULL));
  	int c_Id = 0;
  	int i = 0;
  	while(i<4){
  		c_Id = c_Id * power(10, i) + (char)(rand() % 10 + 1);
  		i++;
  	}
  	printf("ID%d\n", c_Id);
  	return c_Id;
}


long unsigned int getBufferContentSize(unsigned char buffer[]) {
	long unsigned int buffSize = 0;

	while (buffer[buffSize] != '\0') {
		buffSize++;
	}
	printf("\n%lu    \n\n", buffSize);
	return buffSize;
}


int main (int argc, char * argv[] )
{
	int sock;                              //This will be our socket
	struct sockaddr_in server, clientaddr;     //"Internet socket address structure"
	unsigned int client_length;            //length of the sockaddr_in structure
	int nbytes;                            //number of bytes we receive in our message
	char buffer[MAXBUFSIZE];               //a buffer to store our received message
	unsigned char file_buf[BUFSIZE];
	int serv = getClientID();
	if (argc != 2)
	{
		printf ("USAGE:  <port>\n");
		exit(1);
	}

	bzero(&server,sizeof(server));                  //zero the struct
	server.sin_family = AF_INET;                   //get server machine ip
	server.sin_port = htons(atoi(argv[1]));        //htons() sets the port # to network byte order
	server.sin_addr.s_addr = INADDR_ANY;           //supplies the IP address of the local machine


	//Causes the system to create a generic socket of type UDP (datagram)
	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		printf("unable to create socket");
	}

	if (bind(sock, (struct sockaddr *)&server, sizeof(server)) < 0)
	{
		printf("unable to bind socket\n");
	}

	client_length = sizeof(clientaddr);
//*********************************************************MENU**************************************************
	while(1){	
	bzero(buffer,sizeof(buffer));
	nbytes = recvfrom(sock, buffer, MAXBUFSIZE, 0, (struct sockaddr *)&clientaddr, &client_length);
		
	if (nbytes < 0){
		printf("Error in recvfrom\n");
		 }


//*********************************************************PUT FILE****************************************************
	if(!strncmp(buffer,"put",3)){	
	FILE *file;


	while (1) {
		printf("START---\n");				//start receiving file
		
 		
 		bzero(buffer,sizeof(buffer));
	    struct packet pac;

	    if (recvfrom(sock, &pac, sizeof(packet), 0, (struct sockaddr *)&clientaddr, &client_length)<0)
	    {
	    	printf("error in recieving the file\n");
	    	continue;
	    }
		

	    char filename[100];
	    strcpy(filename, "./serverDir/");
	    strcat(filename, pac.filename);
	    strcat(filename, "_new");

	    printf("FILENAME: %s   %s\n", filename, pac.filename);
	    file = fopen(filename,"ab");
	   
	    int c_Id = pac.c_Id;						
	    unsigned char *file_buffer = pac.data;					
	    memcpy(file_buffer, pac.data, pac.dataSize);
	    int fileSize = fwrite(file_buffer , sizeof(unsigned char), pac.dataSize, file);

	    printf("CLIENT ID:%d:\n", pac.c_Id);
	    printf("DATA SIZE:%d:\n", pac.dataSize);
	  	printf("Buffer Content:%d  %lu   %lu  %lu\n", fileSize, sizeof(file_buffer), getBufferContentSize(file_buffer), getBufferContentSize(pac.data));
	  	printf("BUFFER:%s:\n\n", pac.data);

	    if( fileSize < 0)
	    {
	    	printf("error writting file\n");
	        exit(1);
	    }

		nbytes = sendto(sock, "Packet received\n", 17, 0, (struct sockaddr *)&clientaddr, client_length);
		if (nbytes < 0){
			printf("Error in sendto\n");
		}
	
		
		fclose(file);
		printf("END OF PACKET\n\n");
	}

}
//********************************************************GET FILE*******************************************************************

	if (!strncmp(buffer, "get", 3))
	{
	//Read a file.
	FILE *file;
	//printf("Enter the file name:");
	//get the file name from the user
	char f[100];
	 bzero(buffer,sizeof(buffer));
		nbytes = recvfrom(sock, buffer, MAXBUFSIZE, 0, (struct sockaddr *)&clientaddr, &client_length);
		
		 if (nbytes < 0){
		 	printf("Error in recvfrom\n");
		 }
	strcpy(f,buffer);

	file = fopen(f, "r");

	
	if(file == NULL)
    {
      printf("file does not exist\n");
    }

  	size_t file_size = getFileSize(file); 		
  	printf("file_size: %lu\n\n", file_size);

  	fseek(file, 0, SEEK_SET);

  	int count = 0;
  	int totalPackets = getTotalNumberOfPackets(file_size);

  	while (count < totalPackets) {
  		printf("START---\n");
	  	int byte_read = fread(file_buf, sizeof(unsigned char), BUFSIZE, file);
	  	if( byte_read <= 0)
	    {
	      printf("unable to copy file into file_buf\n");
	      exit(1);
	    }

	    struct packet pack;
	    pack.c_Id = serv;
	    memset(pack.filename, '\0', sizeof(pack.filename));
	    strcpy(pack.filename,f);
		pack.dataSize = byte_read;

	    memcpy(pack.data, file_buf, sizeof(file_buf));

	    printf("CLIENT ID:%d**%d:\n\n", serv, pack.c_Id);
	    printf("DATA SIZE:%d:\n", pack.dataSize);
	  	printf("Buffer Content:%d  %lu   %lu  %lu\n", byte_read, sizeof(file_buf), getBufferContentSize(file_buf), getBufferContentSize(pack.data));
	  	printf("BUFFER:%s:\n\n", pack.data);

	    nbytes = sendto(sock, &pack, sizeof(packet), 0, (struct sockaddr *)&clientaddr, sizeof(clientaddr));

	    if (nbytes < 0){
			printf("Error in sendto\n");
		}

	  	bzero(file_buf,sizeof(file_buf));
	    //Read a file ends
	int msec = 0, trigger = 2; // 10ms 
clock_t before = clock();

do {
 if((nbytes = recvfrom(sock, buffer, MAXBUFSIZE, 0, (struct sockaddr *)&clientaddr, &client_length))<0)
	{
		nbytes = sendto(sock, &pack, sizeof(packet), 0, (struct sockaddr *)&clientaddr, sizeof(clientaddr));
	    	if (nbytes < 0){
			printf("Error in sendto\n");
			}
	}
	  
  clock_t difference = clock() - before;				//TIMER IS SET HERE!!
  msec = difference * 1000 / CLOCKS_PER_SEC;
 
} while ( msec < trigger );

		
		unsigned int client_length = sizeof(clientaddr);
		nbytes = recvfrom(sock, buffer, MAXBUFSIZE, 0, (struct sockaddr *)&clientaddr, &client_length);  

		//printf("Server says %s\n", buffer);
		count++;
		printf("END OF PACKET\n\n");
	}
	}
//*********************************************************DELETE FILE*********************************************************
if (!strncmp(buffer,"delete",6))
{
	bzero(buffer,sizeof(buffer));
	nbytes = recvfrom(sock, buffer, MAXBUFSIZE, 0, (struct sockaddr *)&clientaddr, &client_length);
	if (nbytes < 0){
	 	printf("Error in recvfrom\n");
	 }
	FILE *fp;
	fp=fopen(buffer,"r");
	if (fp==NULL)
	{
		char uhoh[]="No file like that exists";
		nbytes = sendto(sock,uhoh , strlen(uhoh), 0, (struct sockaddr *)&clientaddr, sizeof(clientaddr));

		if (nbytes < 0){
			printf("Error in sendto\n");
		}
		bzero(buffer,sizeof(buffer));
	}
	else
	{
		remove(buffer);
		char done[]="File removed";
		nbytes = sendto(sock, done, strlen(done), 0, (struct sockaddr *)&clientaddr, sizeof(clientaddr));

		if (nbytes < 0){
			printf("Error in sendto\n");
		}
		bzero(buffer,sizeof(buffer));
	}
}
//*********************************************************LIST****************************************************************
if (!strncmp(buffer,"ls",2))
{
	char *curr_dir = NULL; 
    DIR *dp = NULL; 
    struct dirent *dptr = NULL; 
    unsigned int count = 0; 
	char d[100];
  
    curr_dir = getenv("PWD"); 
    if(NULL == curr_dir) 
    { 
        strcpy(d,"\n ERROR : Could not get the working directory\n"); 
        return -1; 
    } 
  
    dp = opendir((const char*)curr_dir); 
    if(NULL == dp) 
    { 
        strcpy(d,"\n ERROR : Could not open the working directory\n"); 
        return -1; 
    } 
  
    printf("\n"); 
    for(count = 0; NULL != (dptr = readdir(dp)); count++) 
    { 
        // Check if the name of the file/folder begins with '.' 
        // If yes, then do not display it. 
        if(dptr->d_name[0] != '.') 
            strcpy(d,dptr->d_name);
	nbytes = sendto(sock, d, strlen(d), 0, (struct sockaddr *)&clientaddr, sizeof(clientaddr));

	if (nbytes < 0){
	printf("Error in sendto\n");
	}
	bzero(buffer,sizeof(buffer));
 
    } 
	






}
//********************************************************EXIT*****************************************************************

if (!strncmp(buffer,"exit",4))
	close(sock);

//********************************************************END OF PROGRAM********************************************************
}

}


		
